<?php

// src/Controller/DestinationController.php

namespace App\Controller;

use App\Form\DestinationType;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Destination;
use Doctrine\ORM\EntityManagerInterface; // Importez l'EntityManagerInterface


class DestinationController extends AbstractController
{
    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /**
     * @Route("/destination/{id}", name="destination_show")
     */
    public function show($id): Response
    {
        // Récupérez la destination à partir de la base de données en utilisant l'EntityManager
        $destination = $this->entityManager->getRepository(Destination::class)->find($id);

        if (!$destination) {
            throw $this->createNotFoundException('Destination non trouvée');
        }

        return $this->render('destination/show.html.twig', [
            'destination' => $destination,
        ]);
    }
    /**
     * @Route("/destination/add", name="destination_add")
     */
    public function add(): Response
    {
        // Créez un formulaire pour l'ajout de destination (nous allons le créer dans l'étape suivante)
        $form = $this->createForm(DestinationType::class);

        return $this->render('destination/add.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}
